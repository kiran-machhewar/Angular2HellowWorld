export interface Account {
    Id: string;
    Name: string;
};